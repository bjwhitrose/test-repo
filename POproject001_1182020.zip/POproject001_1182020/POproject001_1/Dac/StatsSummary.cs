﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dac
{
    public class StatsSummary
    {
        public int Simulid { get; set; }
        public string Tier { get; set; }
        public int CustCNT { get; set; }
        public string SalesAMT { get; set; }
        public string CUSTPROP { get; set; }
        public string SALESPROP { get; set; }
    }
}
