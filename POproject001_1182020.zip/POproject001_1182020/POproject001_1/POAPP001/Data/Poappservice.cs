﻿
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using POAPP001.Data;
using Dac;


namespace POAPP001.Data
{
    public class Poappservice
    {
        private readonly POAPP001Context _context;

        public Poappservice(POAPP001Context context)
        {
            _context = context;
        }
        public Task<List<PlanHead>> GetPlanHeadAsync()
        {
            List<PlanHead> colPlanHeadResult =
                 new List<PlanHead>();
            colPlanHeadResult =
                (from assessresult in _context.PlanHead
                 select assessresult).ToList();

            
            return Task.FromResult(colPlanHeadResult);

        }


        public Task<PlanHead> CreatePlanHeadAsync(PlanHead objPlanHead)
        {
            _context.PlanHead.Add(objPlanHead);
            //create detail
            _context.SaveChanges();
          
            return Task.FromResult(objPlanHead);
        }

        public Task<AccessmentSimulation> CreateSimulAsync(AccessmentSimulation objSimul)
        {
            _context.AccessmentSimulation.Add(objSimul);
            _context.SaveChanges();
            return Task.FromResult(objSimul);
        }
        public Task<List<AccessmentSimulation>> GetSimulAsync()
        {
            List<AccessmentSimulation> colSimulResult =
                 new List<AccessmentSimulation>();
            colSimulResult =
                (from assessresult in _context.AccessmentSimulation
                 select assessresult).ToList();


            return Task.FromResult(colSimulResult);

        }
        public Task<List<AccessmentSimulation>> GetSimulAsync(object value)
        {
            List<AccessmentSimulation> colSimulResult =
                 new List<AccessmentSimulation>();
            colSimulResult =
                (from assessresult in _context.AccessmentSimulation
                 where assessresult.Simulationid == System.Convert.ToInt32(value.ToString())
                 select assessresult).ToList();


            return Task.FromResult(colSimulResult);

        }
        public Task<TierPlanHead> CreateTierPlanHeadAsync(TierPlanHead objTierPlanHead)
        {
            _context.TierPlanHead.Add(objTierPlanHead);
            _context.SaveChanges();
            return Task.FromResult(objTierPlanHead);
        }
        public void CreatePlanDetailAsync(PlanHead objPlanHead)
        {

            spdata spdata = new spdata();
            spdata.spdataexec(objPlanHead.Planid,1);
            
            
        }

        public List<Dac.StatsSummary> GetSummary(int i)
        {
            spdata spdata = new spdata();

            List<Dac.StatsSummary> stats = new List<Dac.StatsSummary>();
            stats = spdata.spsimulsummary(i);
            return stats;
        }
        public void CreateTierPlanDetailAsync(TierPlanHead objTierPlanHead)
        {
            spdata spdata = new spdata();
            spdata.spdatatierexec(objTierPlanHead.Tierplanid, objTierPlanHead.Tiercount);
        }
        public Task<List<PlanHead>> GetPlanAsync(long planid)
        {
            List<PlanHead> colPlanHeadResult =
                 new List<PlanHead>();
            colPlanHeadResult =
                (from assessresult in _context.PlanHead
                 where assessresult.Planid == planid
                 select assessresult).ToList();
            return Task.FromResult(colPlanHeadResult);

        }
        public Task<List<PlanDetail>> GetPlanDetailAsync(long planid)
        {
            List<PlanDetail> colPlanDetailResult =
                 new List<PlanDetail>();
            colPlanDetailResult =
                (from assessresult in _context.PlanDetail
                 where assessresult.PlanHeadid == planid
                 select assessresult).ToList();
            return Task.FromResult(colPlanDetailResult);

        }
        public Task<List<TierPlanDetail>> GetTierPlanDetailAsync(long tierplanid)
        {
            List<TierPlanDetail> colPlanDetailResult =
                 new List<TierPlanDetail>();
            colPlanDetailResult =
                (from assessresult in _context.TierPlanDetail
                 where assessresult.Tierplanid == tierplanid
                 select assessresult).ToList();
            return Task.FromResult(colPlanDetailResult);
        }
        public Task<List<TierPlanHead>> GetTierPlanHeadAsync(long tierplanid)
        {
            List<TierPlanHead> colPlanDetailResult =
                 new List<TierPlanHead>();
            colPlanDetailResult =
                (from assessresult in _context.TierPlanHead
                 select assessresult).ToList();
            return Task.FromResult(colPlanDetailResult);
        }
        public Task<List<TierPlanHead>> GetTierPlanHeadAsync()
        {
            List<TierPlanHead> colPlanDetailResult =
                 new List<TierPlanHead>();
            colPlanDetailResult =
                (from assessresult in _context.TierPlanHead
                     select assessresult).ToList();
            return Task.FromResult(colPlanDetailResult);
        }
    }
    
}
