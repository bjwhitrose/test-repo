﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using POAPP001.Data;

namespace POAPP001.Data
{
    public class Poappservice
    {
        private readonly POAPP001Context _context;

        public Poappservice(POAPP001Context context)
        {
            _context = context;
        }
        public Task<List<PlanHead>> GetPlanHeadAsync()
        {
            List<PlanHead> colPlanHeadResult =
                 new List<PlanHead>();
            colPlanHeadResult =
                (from assessresult in _context.PlanHead
                 select assessresult).ToList();
            return Task.FromResult(colPlanHeadResult);

        }

        public Task<PlanHead> CreatePlanHeadAsync(PlanHead objPlanHead)
        {
            _context.PlanHead.Add(objPlanHead);
            _context.SaveChanges();
            return Task.FromResult(objPlanHead);
        }
    }
    
}
