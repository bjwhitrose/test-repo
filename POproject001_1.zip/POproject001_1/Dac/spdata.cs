﻿using System.Configuration;
using System.Data.SqlClient;


namespace Dac
{
    public class spdata
    {

        SqlConnection conn = new SqlConnection("Data source = localhost;initial catalog=poproject;Integrated Security=True");

        //string a = "te";
        
        public void spdataexec(long id,int cnt)
        {
            
            conn.Open();
            SqlCommand command = new SqlCommand("InsertPlanDetail", conn);
            command.CommandType = System.Data.CommandType.StoredProcedure;
            command.Parameters.Add(new SqlParameter("@planid", id));
            command.Parameters.Add(new SqlParameter("@factorcnt", cnt));
            command.ExecuteNonQuery();

            conn.Close();
        }

        public void spdatatierexec(long id,long cnt)
        {

            conn.Open();
            SqlCommand command = new SqlCommand("InsertTierPlanDetail", conn);
            command.CommandType = System.Data.CommandType.StoredProcedure;
            command.Parameters.Add(new SqlParameter("@tierplanid", id));
            command.Parameters.Add(new SqlParameter("@tiernumber", cnt));
            command.ExecuteNonQuery();

            conn.Close();
        }


    }
}
