﻿using System.Configuration;
using System.Data.SqlClient;
using System.Collections.Generic;


namespace Dac
{
    public class spdata
    {

        SqlConnection conn = new SqlConnection("Data source = hznjdb1;initial catalog=business_al;Integrated Security=True");
        SqlDataReader reader;
        //string a = "te";
        
        public void spdataexec(long id,int cnt)
        {
            
            conn.Open();
            SqlCommand command = new SqlCommand("Customer.InsertPlanDetail", conn);
            command.CommandType = System.Data.CommandType.StoredProcedure;
            command.Parameters.Add(new SqlParameter("@planid", id));
            command.Parameters.Add(new SqlParameter("@factorcnt", cnt));
            command.ExecuteNonQuery();

            conn.Close();
        }

        public void spdatatierexec(long id,long cnt)
        {

            conn.Open();
            SqlCommand command = new SqlCommand("Customer.InsertTierPlanDetail", conn);
            command.CommandType = System.Data.CommandType.StoredProcedure;
            command.Parameters.Add(new SqlParameter("@tierplanid", id));
            command.Parameters.Add(new SqlParameter("@tiernumber", cnt));
            command.ExecuteNonQuery();

            conn.Close();
        }
        public List<StatsSummary> spsimulsummary(int id)
        {

            conn.Open();
            SqlCommand command = new SqlCommand("Customer.SimulSummaryStats", conn);
            command.CommandType = System.Data.CommandType.StoredProcedure;
            command.Parameters.Add(new SqlParameter("@SIMULID", id));
            reader =  command.ExecuteReader();
            List<StatsSummary> stats = new List<StatsSummary>();
            StatsSummary stat = null;

            while (reader.Read())
            {
                stat = new StatsSummary();
                stat.Tier = reader["Tier"].ToString();
                stat.CustCNT = System.Convert.ToInt32(reader["CUSTCOUNT"].ToString());
                stat.SalesAMT =  reader["SALESAMOUNT"].ToString();
                stat.CUSTPROP = reader["CUSTPROP"].ToString();
                stat.SALESPROP = reader["SALESPROP"].ToString();
                stats.Add(stat);
            }
            conn.Close();

            return stats;
          
        }

    }
}
